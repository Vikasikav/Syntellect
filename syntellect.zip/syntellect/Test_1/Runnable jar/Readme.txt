
Please find below command to execute the program.
============================================================

cmd :- "C:\Program Files\Java\jdk1.8.0_331\bin\java.exe" -jar TicketGenerator.jar