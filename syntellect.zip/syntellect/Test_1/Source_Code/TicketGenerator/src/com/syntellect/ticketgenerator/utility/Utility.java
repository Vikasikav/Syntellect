package com.syntellect.ticketgenerator.utility;

import java.util.Random;

public class Utility {
	
	
	public static int getValidatedValue(int i, int j, int[][] ticket) {
		// TODO Auto-generated method stub
	
		int data=0;
		boolean isValueSet=false;
	
		int colsCounter=0;
		int rowCounter=0;
		
		
		try {
		
		if(ticket[i][j]!=0){
			
			return -1;
		}
		
		
		for(int r=0; r<3; r++) {
			
			if(ticket[r][j]!=0) {
				
				colsCounter++;
			}
		}
		
		if(colsCounter>=2) {
			
			return -1;
		}
		
		
		for(int c=0; c<9; c++) {
			
			if(ticket[i][c]!=0) {
				
				rowCounter++;
			}
		}
		
		if(rowCounter>=5) {
			
			return -1;
		}

		do {
			data=getRandomNumberForColRange(j);
			
			isValueSet=isValueExistsCol(ticket,i,j,data);
		}
		while(isValueSet);

		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		return data;
	}

	public static boolean isValueExistsCol(int[][] ticket, int i, int j, int data) {
		// TODO Auto-generated method stub
		boolean status=false;
		
		try {
		for(int k=0; k<3;k++) {
		
			if(ticket[k][j]==data){
				
				status=true;
				break;
			}
		}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return status;
	}

	public static int getRandomNumberForColRange(int upperRange) {
		// TODO Auto-generated method stub
		
		Random random=new Random();
		
		
		if(upperRange==0) {
			upperRange=10;
		}
		else {
			
			upperRange=(upperRange+1)*10;
			
		}
		int low=upperRange-9;
		
		
			
		return random.nextInt(upperRange-low)+low;
	}

	public static int getRandomNumber(int max) {
		// TODO Auto-generated method stub
		return (int)(Math.random()*max);
	}

}
