package com.syntellect.ticketgenerator;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

import com.syntellect.ticketgenerator.exception.CustomException;
import com.syntellect.ticketgenerator.utility.Utility;

public class TicketGenerator {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		System.out.println("================================================================");
		System.out.println("********************Housie Ticket Generator*********************");
		System.out.println("================================================================");
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.print("Please Enter no. of Rows     ::  ");
	
		int noOfRows=sc.nextInt();
		
		System.out.print("Please Enter no. of Columns  ::  ");
		
		int noOfCols=sc.nextInt();
		
        System.out.print("Please Enter no. of Players  ::  ");
		
		int players=sc.nextInt();
		
		
		for(int i=1; i<= players; i++) {
		
			System.out.println("================================================================");
			System.out.println("********************  Player "+i+"********************************");
			System.out.println("================================================================");
			System.out.println();	
			getGeneratedTicket(noOfRows,noOfCols);
			System.out.println();	
			
		}
		
	}

	private static void  getGeneratedTicket(int r, int c) {
		
		int ticket[][]=new int[r][c];
        int filledCellsLimit=15;
        
        try {
        while(filledCellsLimit>0) {
		
        	int i=Utility.getRandomNumber(r);
        	int j=Utility.getRandomNumber(c);
        
        	int data=Utility.getValidatedValue(i,j,ticket);
		
        	if(data>0) {
        		
        		ticket[i][j]=data;
        		
        		filledCellsLimit--;
        	}
        }

	}
	catch(Exception e) {
	
		e.printStackTrace();
	}

		System.out.println(Arrays.deepToString(ticket).replace("],", "]\n").replace(",", " || ").replace("0", "00").replace("[[", " [").replace("]]", "]"));
	}


}
