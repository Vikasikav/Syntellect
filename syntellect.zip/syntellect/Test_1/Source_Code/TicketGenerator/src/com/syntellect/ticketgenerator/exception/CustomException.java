package com.syntellect.ticketgenerator.exception;

public class CustomException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7667031885167708784L;

	public CustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

