select  p.id,p.name,c.content,p.authorid,c.userid,c.createdts 
   from post p 
   INNER JOIN 
   comment c on p.id=c.postid 
   where p.authorid IN 
   (select id from author where name='James Bond') and
    c.content In ( select content from comment  order by createdts desc);
   