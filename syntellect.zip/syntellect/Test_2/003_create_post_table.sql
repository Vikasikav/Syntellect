CREATE TABLE `post` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `authorid` bigint NOT NULL,
  `createdts` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `authorid` (`authorid`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`authorid`) REFERENCES `author` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci